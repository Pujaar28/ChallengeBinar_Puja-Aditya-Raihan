abstract class AbstractGameplay {
    abstract fun regulation(player1: String, player2: String)

}